package animal;

//O uso do extends indica que uma classe foi herdada de outra.

public class Cachorro extends Animal {

	 public String orelha;
	 public String cor;
	 private String pelo;
	 
	//Geração de um contrutor para inicializar as variaveis 
	 
	public Cachorro(String nome, int idade, String orelha,String cor, String pelo) {
		super(nome, idade);
		this.orelha = orelha;
		this.cor = cor;
		this.pelo = pelo;
	}
	 //Aqui temos o "Getters" que pegam o valor de uma variável e "Setters" que servem pra mudar esse valor dentro do objeto.
	
	public String getOrelha() {
		return orelha;
	}
	public void setOrelha(String orelha) {
		this.orelha = orelha;
	}
	public String getCor() {
		return cor;
	}
	
	public String getPelo() {
		return pelo;
	}
	public void setPelo(String pelo) {
		this.pelo = pelo;
	}
	
	public void setCor(String cor) {
        // Restrições: A cor do cachorro não pode ser alterada após a definição inicial
        System.out.println("A cor do cachorro não pode ser alterada.");
	}
	
	/*aqui temos o if  e else Se o nome do serviço combinar com um desses, 
	  ele retorna o preço. Caso contrário ele retorna
	 
	 */
	
	@Override
	public double calcularPrecoServico(String servico) {
		 if (servico.equals("Banho")) {
	            return 30.0;
	        } else if (servico.equals("Tosa")) {
	            return 50.0;
	        } else if (servico.equals("Consulta")) {
	            return 100.0;
	        }
	        return 0.0;
		
	}
	
	 
}
	