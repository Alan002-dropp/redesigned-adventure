package animal;

public class Servico {

	private String servico;
	private Animal animal ;
	
	//Geração de um contrutor para inicializar as variaveis 
	
	public Servico(String servico, Animal animal) {
		super();
		this.servico = servico;
		this.animal = animal;
	}
	
	 public double calcularPreco() {
	        return animal.calcularPrecoServico(servico);
	    }
	
	
	

	
}
