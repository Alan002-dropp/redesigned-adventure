package animal;

public class Animal {
	
	 
	private String nome;
   	private int idade; 
   	
  //Geração de um contrutor para inicializar as variaveis 
   	
   	public Animal(String nome, int idade) {
		super();
		this.nome = nome;
	    this.idade = idade;
	
	  //Aqui temos o "Getters" que pegam o valor de uma variável e "Setters" que servem pra mudar esse valor dentro do objeto.
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getIdade() {
		return idade;
	}

	public void setIdade(int idade) {
		this.idade = idade;
	}

	public double calcularPrecoServico(String servico) {
		return idade;
		
	}

	
	}

   	


