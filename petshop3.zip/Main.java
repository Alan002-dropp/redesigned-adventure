package main;

// aqui foi usado o import que serve para trazer classes ou pacotes externos para dentro do código

import animal.Animal;
import animal.Cachorro;
import animal.Cavalo;
import animal.Passaro;
import animal.Servico;

public class Main {
	
	// Foi usado herança e polimorfismo para criar as variaveis do tipo animal 
	  
	 
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 // Criando diferentes tipos de animais com suas característi
        Animal cachorro = new Cachorro("Toto", 5, "Curto", "azul", "Preto");
        Animal cavalo = new Cavalo("Poltrano", 7, 1.80, "Árabe", 450.0);
        Animal passaro = new Passaro("Voador", 2, "Amarelo", 0.25, "Curto");

        // Criando serviços para os animais
        Servico banhoCachorro = new Servico("Banho", cachorro);
        Servico banhoCavalo = new Servico("Banho", cavalo);
        Servico banhoPassaro = new Servico("Banho", passaro);
        
        Servico tosaCavalo = new Servico("Tosa", cavalo);
        Servico tosaCachorro = new Servico("Tosa", cachorro);
        Servico tosaPassaro = new Servico("Tosa", passaro);
        
        
        Servico consultaPassaro = new Servico("Consulta", passaro);
        Servico consultaCachorro = new Servico("Consulta", cachorro);
        Servico consultaCavalo = new Servico("Consulta", cavalo);

        /*Exibindo os preços dos serviços, O código chama o método calcularPreco()
        para calcular e imprimir o preço dos serviços
        */
        System.out.println("Preço do banho do cachorro: R$ " + banhoCachorro.calcularPreco());
        System.out.println("Preço da tosa do cachorro: R$ " + tosaCachorro.calcularPreco());
        System.out.println("Preço da consulta do cachorro: R$ " + consultaCachorro.calcularPreco());
        
        System.out.println("Preço do banho do cavalo: R$ " + banhoCavalo.calcularPreco());
        System.out.println("Preço da tosa do cavalo: R$ " + tosaCavalo.calcularPreco());
        System.out.println("Preço da consulta do cavalo: R$ " + consultaCavalo.calcularPreco());
        
        System.out.println("Preço do banho do pássaro: R$ " + banhoPassaro.calcularPreco());
        System.out.println("Preço da aparar penas do pássaro: R$ " + tosaPassaro.calcularPreco());
        System.out.println("Preço da consulta do pássaro: R$ " + consultaPassaro.calcularPreco());
    }
		
	

	}


