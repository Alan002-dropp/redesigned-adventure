package animal;

//O uso do extends indica que uma classe foi herdada de outra.

public class Cavalo extends Animal {
	
	public double altura;
	private String raça;
	public double peso ;
	
	//Geração de um contrutor para inicializar as variaveis 
	
	public Cavalo(String nome, int idade, double altura, String raça, double peso) {
		super(nome, idade);
		this.altura = altura;
		this.raça = raça;
		this.peso = peso;
	}

    //Aqui temos o "Getters" que pegam o valor de uma variável e "Setters" que servem pra mudar esse valor dentro do objeto.
	
	public double getAltura() {
		return altura;
	}

	public void setAltura(double altura) {
		this.altura = altura;
	}

	public String getRaça() {
		return raça;
	}

	public void setRaça(String raça) {
		this.raça = raça;
	}

	public double getPeso() {
		return peso;
	}

	public void setpeso(double peso) {
        
		// Restrições: Não podemos alterar o peso  se o animal tiver mais que 200kg
		
        if (peso >200) {
            System.out.println("Não é permitido alterar o peso do cavalo para mais de 500kg.");
        } else {
            this.peso = peso;
        }
    }
	/*aqui temos o if  e else Se o nome do serviço combinar com um desses, 
	  ele retorna o preço. Caso contrário ele retorna
	 
	 */
	 
	@Override
	public double calcularPrecoServico(String servico) {
		 if (servico.equals("Banho")) {
	            return 180.0;
	        } else if (servico.equals("Tosa")) {
	            return 200.0;
	        } else if (servico.equals("Consulta")) {
	            return 400.0;
	        }
	        return 0.0;
		
	
	}
	
	

}

	