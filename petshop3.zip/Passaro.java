package animal;

//O uso do extends indica que uma classe foi herdada de outra.

public class Passaro extends Animal {
	
	private String asas;
    public double pena;
	public String bico;
	
	//Geração de um contrutor para inicializar as variaveis 
	public Passaro(String nome, int idade, String asas, double pena, String bico) {
		super(nome, idade);
		this.asas = asas;
		this.pena = pena;
		this.bico = bico;
	}

	 //Aqui temos o "Getters" que pegam o valor de uma variável e "Setters" que servem pra mudar esse valor dentro do objeto.
	
	public String getAsas() {
		return asas;
	}

	public void setAsas(String asas) {
		this.asas = asas;
	}

	public double getPena() {
		return pena;
	}

	public void setPena(double pena) {
		this.pena = pena;
	}

	public String getBico() {
		return bico;
	}

	public void setBico(String bico) {
		this.bico = bico;
	}
	
	/*aqui temos o if  e else Se o nome do serviço combinar com um desses, 
	  ele retorna o preço. Caso contrário ele retorna
	 
	 */

	@Override
	public double calcularPrecoServico(String servico) {
		 if (servico.equals("Banho")) {
	            return 10.0;
	        } else if (servico.equals("Tosa")) {
	            return 30.0;
	        } else if (servico.equals("Consulta")) {
	            return 70.0;
	        }
	        return 0.0;
		
	
	}
	
	
		
	
	
}